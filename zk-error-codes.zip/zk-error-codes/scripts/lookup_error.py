#!/usr/bin/env python3
"""
Quick error code lookup utility for ZK kernel development.
"""

import sys
import os

# Error mappings
ERRORS = {
    1: ("EPERM", "PermissionDenied", "Operation not permitted"),
    2: ("ENOENT", "NoSuchFileOrDirectory", "No such file or directory"),
    3: ("ESRCH", "NoSuchProcess", "No such process"),
    4: ("EINTR", "Interrupted", "Interrupted system call"),
    5: ("EIO", "IoError", "I/O error"),
    6: ("ENXIO", "NoSuchDevice", "No such device or address"),
    7: ("E2BIG", "ArgumentListTooLong", "Argument list too long"),
    8: ("ENOEXEC", "ExecFormatError", "Exec format error"),
    9: ("EBADF", "BadFileDescriptor", "Bad file descriptor"),
    10: ("ECHILD", "NoChildProcesses", "No child processes"),
    11: ("EAGAIN", "WouldBlock", "Resource temporarily unavailable"),
    12: ("ENOMEM", "OutOfMemory", "Out of memory"),
    13: ("EACCES", "AccessDenied", "Permission denied"),
    14: ("EFAULT", "BadAddress", "Bad address"),
    16: ("EBUSY", "DeviceBusy", "Device or resource busy"),
    17: ("EEXIST", "FileExists", "File exists"),
    20: ("ENOTDIR", "NotADirectory", "Not a directory"),
    21: ("EISDIR", "IsADirectory", "Is a directory"),
    22: ("EINVAL", "InvalidArgument", "Invalid argument"),
    24: ("EMFILE", "TooManyOpenFiles", "Too many open files"),
    28: ("ENOSPC", "NoSpace", "No space left on device"),
    29: ("ESPIPE", "IllegalSeek", "Illegal seek"),
    30: ("EROFS", "ReadOnlyFilesystem", "Read-only file system"),
    31: ("EMLINK", "TooManyLinks", "Too many links"),
    36: ("ENAMETOOLONG", "FilenameTooLong", "File name too long"),
    38: ("ENOSYS", "NotImplemented", "Function not implemented"),
    39: ("ENOTEMPTY", "DirectoryNotEmpty", "Directory not empty"),
    40: ("ELOOP", "TooManySymbolicLinks", "Too many symbolic links"),
}

def lookup_by_errno(errno):
    """Lookup error by errno number."""
    if errno in ERRORS:
        name, zig_error, desc = ERRORS[errno]
        print(f"Errno:  {errno}")
        print(f"Name:   {name}")
        print(f"Zig:    error.{zig_error}")
        print(f"Desc:   {desc}")
        return True
    return False

def lookup_by_name(search_term):
    """Lookup error by name (errno macro or Zig error name)."""
    search = search_term.upper().replace("ERROR.", "")
    found = False

    for errno, (name, zig_error, desc) in ERRORS.items():
        if search in name.upper() or search in zig_error.upper():
            if not found:
                print("\nMatches:")
            print(f"\n  Errno:  {errno}")
            print(f"  Name:   {name}")
            print(f"  Zig:    error.{zig_error}")
            print(f"  Desc:   {desc}")
            found = True

    return found

def list_all():
    """List all error codes."""
    print("ZK Error Codes:\n")
    print(f"{'Errno':<6} {'Name':<20} {'Zig Error':<30} {'Description'}")
    print("-" * 100)
    for errno in sorted(ERRORS.keys()):
        name, zig_error, desc = ERRORS[errno]
        print(f"{errno:<6} {name:<20} error.{zig_error:<29} {desc}")

def search_description(term):
    """Search error descriptions."""
    term_lower = term.lower()
    found = False

    for errno, (name, zig_error, desc) in ERRORS.items():
        if term_lower in desc.lower():
            if not found:
                print("\nMatches:")
            print(f"\n  Errno:  {errno}")
            print(f"  Name:   {name}")
            print(f"  Zig:    error.{zig_error}")
            print(f"  Desc:   {desc}")
            found = True

    return found

def main():
    if len(sys.argv) < 2:
        print("Usage: lookup_error.py <errno|name|keyword>")
        print("       lookup_error.py --list")
        print("")
        print("Examples:")
        print("  lookup_error.py 39              # Lookup by errno")
        print("  lookup_error.py ENOTEMPTY       # Lookup by errno name")
        print("  lookup_error.py DirectoryNotEmpty  # Lookup by Zig error name")
        print("  lookup_error.py --list          # List all errors")
        print("  lookup_error.py directory       # Search descriptions")
        sys.exit(1)

    arg = sys.argv[1]

    if arg == "--list" or arg == "-l":
        list_all()
        return

    # Try as errno number
    if arg.isdigit() or (arg.startswith("-") and arg[1:].isdigit()):
        errno = abs(int(arg))
        if lookup_by_errno(errno):
            return
        print(f"Error: errno {errno} not found")
        sys.exit(1)

    # Try as name
    if lookup_by_name(arg):
        return

    # Try description search
    if search_description(arg):
        return

    print(f"No matches found for '{arg}'")
    print("Use --list to see all error codes")
    sys.exit(1)

if __name__ == "__main__":
    main()

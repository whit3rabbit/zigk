# ZK Error Code Mappings

Complete reference for error codes across ZK kernel and userspace.

## Table of Contents
- [Errno to Error Name Mapping](#errno-to-error-name-mapping)
- [Error Details by Category](#error-details-by-category)
- [Implementation Locations](#implementation-locations)
- [Usage Guidelines](#usage-guidelines)

## Errno to Error Name Mapping

Quick reference table for errno values to Zig error types.

| Errno | Error Name | Kernel Error | Userspace SyscallError | Description |
|-------|------------|--------------|------------------------|-------------|
| 1 | EPERM | error.PermissionDenied | error.PermissionDenied | Operation not permitted |
| 2 | ENOENT | error.NoSuchFileOrDirectory | error.NoSuchFileOrDirectory | No such file or directory |
| 3 | ESRCH | error.NoSuchProcess | error.NoSuchProcess | No such process |
| 4 | EINTR | error.Interrupted | error.Interrupted | Interrupted system call |
| 5 | EIO | error.IoError | error.IoError | I/O error |
| 6 | ENXIO | error.NoSuchDevice | error.NoSuchDevice | No such device or address |
| 7 | E2BIG | error.ArgumentListTooLong | error.ArgumentListTooLong | Argument list too long |
| 8 | ENOEXEC | error.ExecFormatError | error.ExecFormatError | Exec format error |
| 9 | EBADF | error.BadFileDescriptor | error.BadFileDescriptor | Bad file descriptor |
| 10 | ECHILD | error.NoChildProcesses | error.NoChildProcesses | No child processes |
| 11 | EAGAIN | error.WouldBlock | error.WouldBlock | Resource temporarily unavailable |
| 12 | ENOMEM | error.OutOfMemory | error.OutOfMemory | Out of memory |
| 13 | EACCES | error.AccessDenied | error.AccessDenied | Permission denied |
| 14 | EFAULT | error.BadAddress | error.BadAddress | Bad address |
| 16 | EBUSY | error.DeviceBusy | error.DeviceBusy | Device or resource busy |
| 17 | EEXIST | error.FileExists | error.FileExists | File exists |
| 20 | ENOTDIR | error.NotADirectory | error.NotADirectory | Not a directory |
| 21 | EISDIR | error.IsADirectory | error.IsADirectory | Is a directory |
| 22 | EINVAL | error.InvalidArgument | error.InvalidArgument | Invalid argument |
| 24 | EMFILE | error.TooManyOpenFiles | error.TooManyOpenFiles | Too many open files |
| 28 | ENOSPC | error.NoSpace | error.NoSpace | No space left on device |
| 29 | ESPIPE | error.IllegalSeek | error.IllegalSeek | Illegal seek |
| 30 | EROFS | error.ReadOnlyFilesystem | error.ReadOnlyFilesystem | Read-only file system |
| 31 | EMLINK | error.TooManyLinks | error.TooManyLinks | Too many links |
| 36 | ENAMETOOLONG | error.FilenameTooLong | error.FilenameTooLong | File name too long |
| 38 | ENOSYS | error.NotImplemented | error.NotImplemented | Function not implemented |
| 39 | ENOTEMPTY | error.DirectoryNotEmpty | error.DirectoryNotEmpty | Directory not empty |
| 40 | ELOOP | error.TooManySymbolicLinks | error.TooManySymbolicLinks | Too many symbolic links |

## Error Details by Category

### Filesystem Errors (Common in Shell)

**ENOENT (2) - No such file or directory**
- Returned when: Path doesn't exist
- Shell commands: ls, cat, rm, mkdir (when parent doesn't exist)
- Example: `ls /nonexistent` → "No such file or directory"

**ENOTDIR (20) - Not a directory**
- Returned when: Path component is not a directory
- Shell commands: cd, ls (when path component is a file)
- Example: `cd /file.txt/subdir` → "Not a directory"

**EISDIR (21) - Is a directory**
- Returned when: Attempting file operation on directory
- Shell commands: cat, rm (without -r)
- Example: `cat /directory` → "Is a directory"

**EEXIST (17) - File exists**
- Returned when: Creating file/dir that already exists
- Shell commands: mkdir (without -p)
- Example: `mkdir /existing_dir` → "File exists"

**ENOTEMPTY (39) - Directory not empty**
- Returned when: Removing non-empty directory
- Shell commands: rmdir
- Example: `rmdir /dir_with_files` → "Directory not empty"
- Fix: Use `rm -r` or remove contents first

**ENOSPC (28) - No space left on device**
- Returned when: Filesystem is full
- Shell commands: write, mkdir, touch
- Example: Write fails when disk is full

**EROFS (30) - Read-only file system**
- Returned when: Write to read-only mount
- Shell commands: write, rm, mkdir, chmod
- Example: `touch /readonly_mount/file` → "Read-only file system"

**ENAMETOOLONG (36) - File name too long**
- Returned when: Path/filename exceeds limits
- Shell commands: Any command with long path
- SFS limit: 32 bytes for filename

### Permission Errors

**EPERM (1) - Operation not permitted**
- Returned when: Lacking required capability
- Shell commands: Operations requiring special permissions
- Example: Hardware access without MMIO capability

**EACCES (13) - Permission denied**
- Returned when: File permission check fails
- Shell commands: open, execute, read, write
- Example: `cat /root/private.txt` (without read permission)

### Process/System Errors

**ESRCH (3) - No such process**
- Returned when: PID doesn't exist
- Syscalls: kill, waitpid

**EINTR (4) - Interrupted system call**
- Returned when: Syscall interrupted by signal
- Handling: Retry the syscall

**ECHILD (10) - No child processes**
- Returned when: wait() with no children
- Syscalls: wait, waitpid

### Resource Errors

**ENOMEM (12) - Out of memory**
- Returned when: Memory allocation fails
- Any operation requiring heap allocation

**EMFILE (24) - Too many open files**
- Returned when: Process FD limit reached
- Syscalls: open, socket, pipe

**EBUSY (16) - Device or resource busy**
- Returned when: Resource in use
- Example: Unmounting mounted filesystem

### I/O Errors

**EIO (5) - I/O error**
- Returned when: Hardware I/O failure
- Any disk/device operation

**EBADF (9) - Bad file descriptor**
- Returned when: Invalid FD number
- Syscalls: read, write, close with invalid FD

**ESPIPE (29) - Illegal seek**
- Returned when: Seeking on non-seekable FD
- Example: seek() on pipe or socket

### Link/Path Errors

**EMLINK (31) - Too many links**
- Returned when: Hard link limit reached
- Syscalls: link

**ELOOP (40) - Too many symbolic links**
- Returned when: Symlink depth limit exceeded
- Any path resolution with circular symlinks

### Implementation Errors

**ENOSYS (38) - Function not implemented**
- Returned when: Syscall not implemented
- Example: Calling unimplemented syscall

**EINVAL (22) - Invalid argument**
- Returned when: Bad parameter to syscall
- Example: Invalid flags, negative size

**E2BIG (7) - Argument list too long**
- Returned when: exec() args exceed limit

**ENOEXEC (8) - Exec format error**
- Returned when: Binary format invalid

## Implementation Locations

### Kernel Error Definitions
**File**: `src/kernel/sys/syscall/core/base.zig`
- Contains kernel SyscallError enum
- Used by syscall handlers
- Automatically converted to -errno by dispatcher

### Userspace Error Definitions
**File**: `src/user/lib/syscall/primitive.zig`
- Contains userspace SyscallError enum (lines 79-100)
- errorFromReturn() converts -errno to error (lines 102-129)

### Errno Constants (libc)
**File**: `src/user/lib/libc/errno.zig`
- Defines errno constants (EPERM = 1, etc.)
- Used by libc functions
- Includes error_strings array for strerror()

### Shell Error Messages
**File**: `src/user/shell/main.zig`
- printError() function (lines 29-46)
- Maps SyscallError to user-friendly messages

### Error Translation (libc)
**File**: `src/user/lib/libc/stdlib/env.zig`
- syscallErrorToErrno() function (lines 350-373)
- Converts SyscallError back to errno for libc

## Usage Guidelines

### Adding New Error Codes

When adding a new error code, update ALL of these locations:

1. **Kernel** (`src/kernel/sys/syscall/core/base.zig`):
   ```zig
   pub const SyscallError = error{
       // ... existing errors ...
       NewErrorName,  // Add here
   };
   ```

2. **Userspace** (`src/user/lib/syscall/primitive.zig`):
   ```zig
   pub const SyscallError = error{
       // ... existing errors ...
       NewErrorName,  // errno XX - Add with comment
   };

   pub fn errorFromReturn(ret: usize) SyscallError {
       return switch (errno_val) {
           // ... existing cases ...
           XX => error.NewErrorName,  // Add mapping
       };
   }
   ```

3. **Errno constants** (`src/user/lib/libc/errno.zig`):
   ```zig
   pub const ENEWNAME: c_int = XX;
   ```

4. **Shell messages** (`src/user/shell/main.zig`):
   ```zig
   fn printError(err: anyerror) void {
       const msg = switch (err) {
           // ... existing cases ...
           error.NewErrorName => "User-friendly message",
       };
   }
   ```

5. **Libc translation** (`src/user/lib/libc/stdlib/env.zig`):
   ```zig
   fn syscallErrorToErrno(err: syscall.SyscallError) c_int {
       return switch (err) {
           // ... existing cases ...
           error.NewErrorName => errno_mod.ENEWNAME,
       };
   }
   ```

6. **HTTP daemon** (if applicable) (`src/user/httpd/main.zig`):
   ```zig
   fn printError(err: syscall.SyscallError) void {
       const msg = switch (err) {
           // ... existing cases ...
           error.NewErrorName => "ENEWNAME",
       };
   }
   ```

### Checking Error Completeness

Grep for exhaustive switch statements that need updating:

```bash
# Find switches on SyscallError
grep -r "switch.*err" src/user/

# Check for missing error cases
# Compiler will error on non-exhaustive switches
zig build
```

### Testing Error Paths

```bash
# Test shell error messages
zig build run -Darch=x86_64 -Ddefault-boot=shell -Dqemu-args="-nographic"

# In shell:
mkdir /test        # EEXIST if exists
rmdir /nonexist   # ENOENT
rmdir /file       # ENOTDIR
ls /nonexist      # ENOENT
```

### Error Return Convention

**Kernel syscalls** return positive values on success, negative errno on error:
```zig
pub fn sys_example() SyscallError!usize {
    if (error_condition) return error.InvalidArgument;  // Returns -22
    return 0;  // Success
}
```

**Userspace** receives negative errno, converts to error:
```zig
const ret = syscall1(SYS_EXAMPLE, arg);
if (isError(ret)) {
    const err = errorFromReturn(ret);  // Converts -22 to error.InvalidArgument
    // Handle error
}
```

## Common Pitfalls

### Error Name Mismatches
Shell code using wrong error names (e.g., `error.ENOENT` instead of `error.NoSuchFileOrDirectory`) will cause "Unknown error" messages.

**Fix**: Always use the SyscallError enum names, not errno macro names.

### Missing Errno Constants
If a new error is added to SyscallError but ENOSOMETHING constant is missing from errno.zig, libc functions will fail to compile.

**Fix**: Add the errno constant with the correct numeric value.

### Non-Exhaustive Switches
Zig requires all switch statements to be exhaustive. Missing an error case causes compilation failure.

**Fix**: Add all new errors to every switch statement, or use `else =>` with a generic message.

### Errno Number Conflicts
Using an errno number that conflicts with Linux standard errno values causes confusion.

**Fix**: Follow Linux errno numbering. Check `man errno` or `asm-generic/errno-base.h`.

## Reference: Linux Errno Values

ZK follows Linux errno numbering for compatibility:

```
EPERM            1      Operation not permitted
ENOENT           2      No such file or directory
ESRCH            3      No such process
EINTR            4      Interrupted system call
EIO              5      I/O error
ENXIO            6      No such device or address
E2BIG            7      Argument list too long
ENOEXEC          8      Exec format error
EBADF            9      Bad file descriptor
ECHILD          10      No child processes
EAGAIN          11      Try again (EWOULDBLOCK)
ENOMEM          12      Out of memory
EACCES          13      Permission denied
EFAULT          14      Bad address
ENOTBLK         15      Block device required
EBUSY           16      Device or resource busy
EEXIST          17      File exists
EXDEV           18      Cross-device link
ENODEV          19      No such device
ENOTDIR         20      Not a directory
EISDIR          21      Is a directory
EINVAL          22      Invalid argument
ENFILE          23      File table overflow
EMFILE          24      Too many open files
ENOTTY          25      Not a typewriter
ETXTBSY         26      Text file busy
EFBIG           27      File too large
ENOSPC          28      No space left on device
ESPIPE          29      Illegal seek
EROFS           30      Read-only file system
EMLINK          31      Too many links
EPIPE           32      Broken pipe
EDOM            33      Math argument out of domain
ERANGE          34      Math result not representable
EDEADLK         35      Resource deadlock would occur
ENAMETOOLONG    36      File name too long
ENOLCK          37      No record locks available
ENOSYS          38      Function not implemented
ENOTEMPTY       39      Directory not empty
ELOOP           40      Too many symbolic links encountered
```

---
name: zk-error-codes
description: Quick reference for ZK kernel errno values, error names, and cross-layer mappings. Use when implementing syscalls, fixing shell error messages, or debugging error handling across kernel/userspace boundary.
---

# ZK Error Codes Reference

Quick reference for error codes in the ZK microkernel, including errno values, Zig error names, and their mappings across kernel and userspace layers.

## When to Use This Skill

Use this skill when:
- Implementing new syscalls and need to return the correct error code
- Fixing shell error messages (when shell shows "Unknown error")
- Adding new error types to the kernel or userspace
- Debugging error handling across the kernel/userspace boundary
- Converting between errno numbers, errno macros (ENOENT), and Zig errors (error.NoSuchFileOrDirectory)

## Quick Lookup

For fast lookups of specific error codes without reading the full reference:

```bash
# Lookup by errno number
python scripts/lookup_error.py 39

# Lookup by errno name
python scripts/lookup_error.py ENOTEMPTY

# Lookup by Zig error name
python scripts/lookup_error.py DirectoryNotEmpty

# Search by keyword
python scripts/lookup_error.py directory

# List all error codes
python scripts/lookup_error.py --list
```

## Common Error Codes (Quick Reference)

These are the most frequently used errors in shell commands and filesystem operations:

| Errno | Name | Zig Error | When You See It |
|-------|------|-----------|-----------------|
| 2 | ENOENT | NoSuchFileOrDirectory | File/directory doesn't exist |
| 17 | EEXIST | FileExists | mkdir on existing directory |
| 20 | ENOTDIR | NotADirectory | Path component is a file, not directory |
| 21 | EISDIR | IsADirectory | Trying to open directory as file |
| 39 | ENOTEMPTY | DirectoryNotEmpty | rmdir on non-empty directory |
| 13 | EACCES | AccessDenied | Permission denied |
| 28 | ENOSPC | NoSpace | Filesystem full |
| 30 | EROFS | ReadOnlyFilesystem | Write to read-only mount |

## Complete Error Reference

For detailed information about all error codes, their meanings, implementation locations, and usage guidelines, read `references/error_mappings.md`.

The reference file contains:
- Complete errno to error name mapping table (40+ errors)
- Error details organized by category (filesystem, permissions, I/O, etc.)
- Shell command examples showing when each error occurs
- Implementation file locations (kernel, userspace, libc, shell)
- Step-by-step guide for adding new error codes
- Common pitfalls and how to avoid them
- Linux errno compatibility notes

## Adding New Error Codes

When adding a new error code to ZK, you must update 5-6 locations to ensure consistency across the kernel/userspace boundary. The process is documented in detail in `references/error_mappings.md` under "Usage Guidelines > Adding New Error Codes".

Quick checklist:
1. Add to kernel SyscallError enum (`src/kernel/sys/syscall/core/base.zig`)
2. Add to userspace SyscallError enum (`src/user/lib/syscall/primitive.zig`)
3. Add mapping in errorFromReturn() (`src/user/lib/syscall/primitive.zig`)
4. Add errno constant (`src/user/lib/libc/errno.zig`)
5. Add shell error message (`src/user/shell/main.zig`)
6. Add libc errno mapping (`src/user/lib/libc/stdlib/env.zig`)

**Important**: Zig requires exhaustive switches, so missing an error in any switch statement will cause a compilation error. This is a safety feature.

## Error Naming Conventions

ZK uses three naming styles for errors:

1. **Errno macros** (C-style): `ENOENT`, `EISDIR`, `ENOTEMPTY`
   - Used in: `src/user/lib/libc/errno.zig` constants
   - Example: `pub const ENOENT: c_int = 2;`

2. **Zig error names** (PascalCase): `NoSuchFileOrDirectory`, `IsADirectory`, `DirectoryNotEmpty`
   - Used in: Kernel and userspace SyscallError enums
   - Example: `error.NoSuchFileOrDirectory`

3. **User messages** (Natural language): "No such file or directory", "Is a directory", "Directory not empty"
   - Used in: Shell printError() function
   - Example: Displayed to users in shell

Always use the appropriate style for the context. Never mix styles (e.g., don't use `error.ENOENT` in Zig code).

## Debugging "Unknown error" Messages

If the shell displays "Unknown error" instead of a proper message:

1. **Check the errno value**: Add debug output in the syscall to see what errno is being returned
2. **Verify userspace mapping**: Check if errno is mapped in `errorFromReturn()` (`src/user/lib/syscall/primitive.zig`)
3. **Verify shell message**: Check if error name is in `printError()` switch (`src/user/shell/main.zig`)
4. **Check for typos**: Error names must match exactly (e.g., `DirectoryNotEmpty`, not `DirectoryNotEmtpy`)

Use the lookup script to verify the error exists:
```bash
python scripts/lookup_error.py <errno_number>
```

## Kernel Error Return Convention

Kernel syscalls use Zig errors, which are automatically converted to negative errno values by the syscall dispatcher:

```zig
pub fn sys_example(arg: usize) SyscallError!usize {
    if (arg == 0) return error.InvalidArgument;  // Becomes -22
    return 0;  // Success
}
```

The dispatcher in `src/kernel/sys/syscall/core/table.zig` catches the error and converts it to the negative errno.

## Userspace Error Handling

Userspace receives negative errno values and converts them back to Zig errors:

```zig
const ret = syscall1(SYS_EXAMPLE, arg);
if (isError(ret)) {  // Checks if ret is negative
    const err = errorFromReturn(ret);  // -22 becomes error.InvalidArgument
    // Handle error
}
```

The `errorFromReturn()` function is the critical conversion point. Missing mappings here cause "Unknown error".

## Testing Error Paths

After adding or modifying error codes, test in the shell:

```bash
zig build run -Darch=x86_64 -Ddefault-boot=shell -Dqemu-args="-nographic"

# Test various error conditions:
ls /nonexistent          # Should show "No such file or directory"
mkdir /existing          # Should show "File exists"
rmdir /non_empty_dir     # Should show "Directory not empty"
cat /directory           # Should show "Is a directory"
```

Each error should display the correct message from `printError()` in `main.zig`, not "Unknown error".
